// router.js — Auth, navigation, route protection
// IMPORTANT: Load FIRST on every page, before components.js and app.js.

(function () {
  'use strict';

  function setUser(user) {
    try { localStorage.setItem('hc_user', JSON.stringify(user)); } catch (e) {}
  }

  function getUser() {
    try {
      var raw = localStorage.getItem('hc_user');
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function clearUser() {
    try { localStorage.removeItem('hc_user'); } catch (e) {}
  }

  // Returns how many folder levels deep we are (0 = root)
  function getDepth() {
    var parts = window.location.pathname.split('/').filter(function(p) {
      return p && !p.match(/\.html$/);
    });
    return parts.length;
  }

  function rootPrefix() {
    var depth = getDepth();
    if (depth === 0) return './';
    var prefix = '';
    for (var i = 0; i < depth; i++) prefix += '../';
    return prefix;
  }

  function resolvePath(rootRelativePath) {
    return rootPrefix() + rootRelativePath;
  }

  function navigate(rootRelativePath) {
    window.location.href = resolvePath(rootRelativePath);
  }

  function requireAuth() {
    if (!getUser()) {
      window.location.href = resolvePath('auth/login.html');
      return false;
    }
    return true;
  }

  function requireRole() {
    var roles = Array.prototype.slice.call(arguments);
    if (!requireAuth()) return false;
    var user = getUser();
    if (roles.length && roles.indexOf(user.role) === -1) {
      var dest = user.role === 'parent'
        ? 'parent/parent-dashboard.html'
        : 'student/student-dashboard.html';
      window.location.href = resolvePath(dest);
      return false;
    }
    return true;
  }

  function logout() {
    clearUser();
    window.location.href = resolvePath('auth/login.html');
  }

  window.setUser     = setUser;
  window.getUser     = getUser;
  window.clearUser   = clearUser;
  window.rootPrefix  = rootPrefix;
  window.resolvePath = resolvePath;
  window.navigate    = navigate;
  window.requireAuth = requireAuth;
  window.requireRole = requireRole;
  window.logout      = logout;
})();
