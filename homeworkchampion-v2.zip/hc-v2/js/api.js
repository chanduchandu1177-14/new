// HomeworkChampion API v10 — D1 + R2
var HC_API = (function(){
  'use strict';
  var BASE = 'https://homeworkchampion-api.chanduchandu1177.workers.dev';
  var GOOGLE_CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com';

  function getToken()  { try{return localStorage.getItem('hc_token')||'';}catch(e){return '';} }
  function setToken(t) { try{localStorage.setItem('hc_token',t);}catch(e){} }
  function clearToken(){ try{localStorage.removeItem('hc_token');}catch(e){} }

  async function apiFetch(path,opts){
    opts=opts||{};
    var tok=getToken();
    var headers={'Content-Type':'application/json'};
    if(tok) headers['Authorization']='Bearer '+tok;
    try{
      var res=await fetch(BASE+path,{method:opts.method||'GET',headers:headers,body:opts.body});
      return await res.json();
    }catch(e){return{ok:false,error:'Network error. Check connection.'};}
  }

  // ── Auth ──────────────────────────────────────────────────────
  async function googleVerify(idToken,wantRole){
    var d=await apiFetch('/api/auth/google-verify',{method:'POST',body:JSON.stringify({idToken:idToken,wantRole:wantRole||''})});
    if(d.ok&&d.token){setToken(d.token);if(d.user)setUser(d.user);}
    return d;
  }
  async function googleAuth(idToken){
    var d=await apiFetch('/api/auth/google',{method:'POST',body:JSON.stringify({idToken:idToken})});
    return d;
  }
  async function completeProfile(idToken,role,username,pin,grade,school,parentUsername){
    var d=await apiFetch('/api/auth/complete-profile',{method:'POST',body:JSON.stringify({idToken:idToken,role:role||'student',username:username,pin:pin,grade:grade||'',school:school||'',parentUsername:parentUsername||''})});
    if(d.ok&&d.token){setToken(d.token);if(d.user)setUser(d.user);}
    return d;
  }
  async function pinLogin(username,pin){
    var d=await apiFetch('/api/auth/pin-login',{method:'POST',body:JSON.stringify({username:username,pin:pin})});
    if(d.ok&&d.token){setToken(d.token);if(d.user)setUser(d.user);}
    return d;
  }
  async function resetPin(idToken,username,newPin){
    return apiFetch('/api/auth/reset-pin',{method:'POST',body:JSON.stringify({idToken:idToken,username:username,newPin:newPin})});
  }
  async function checkUsername(username){
    return apiFetch('/api/auth/check-username?u='+encodeURIComponent(username));
  }
  async function linkAccounts(studentUsername,parentUsername){
    return apiFetch('/api/auth/link-accounts',{method:'POST',body:JSON.stringify({studentUsername:studentUsername,parentUsername:parentUsername})});
  }
  function fullLogout(){
    clearToken();
    try{localStorage.removeItem('hc_user');}catch(e){}
    try{if(window.google&&google.accounts&&google.accounts.id)google.accounts.id.disableAutoSelect();}catch(e){}
  }

  // ── Profile ───────────────────────────────────────────────────
  async function getProfile(){
    var d=await apiFetch('/api/profile');
    if(d.ok&&d.user)setUser(d.user);
    return d;
  }
  async function updateProfile(updates){
    var d=await apiFetch('/api/profile',{method:'PUT',body:JSON.stringify(updates)});
    if(d.ok&&d.user)setUser(d.user);
    return d;
  }
  async function updateAvatar(base64,mime){
    var d=await apiFetch('/api/profile/avatar',{method:'PUT',body:JSON.stringify({photoBase64:base64,mimeType:mime||'image/jpeg'})});
    if(d.ok){}
    return d;
  }

  // ── Notifications ─────────────────────────────────────────────
  async function getNotifications(){
    var d=await apiFetch('/api/notifications');
    return d.ok?d.notifications:[];
  }
  async function markRead(){
    return apiFetch('/api/notifications/read',{method:'PUT'});
  }

  // ── Student ───────────────────────────────────────────────────
  async function getDashboard(){
    return apiFetch('/api/student/dashboard');
  }
  async function uploadHomework(title,photoBase64,mimeType,diaryBase64,diaryMime,note){
    return apiFetch('/api/homework/upload',{method:'POST',body:JSON.stringify({title:title||'Homework',photoBase64:photoBase64,mimeType:mimeType||'image/jpeg',diaryBase64:diaryBase64||'',diaryMime:diaryMime||'',note:note||''})});
  }
  async function getHomeworks(){
    var d=await apiFetch('/api/student/homeworks');
    return d.ok?d.homeworks:[];
  }
  async function getMyTasks(){
    var d=await apiFetch('/api/student/tasks');
    return d.ok?d.tasks:[];
  }
  async function completeTask(taskId,proofBase64,proofMime){
    return apiFetch('/api/task/complete',{method:'POST',body:JSON.stringify({taskId:taskId,proofBase64:proofBase64||'',proofMime:proofMime||''})});
  }
  async function getStarProgress(){
    return apiFetch('/api/student/star-progress');
  }
  async function getParents(){
    var d=await apiFetch('/api/student/parents');
    return d.ok?d.parents:[];
  }
  async function sendLinkRequest(parentUsername){
    return apiFetch('/api/parent/link-request',{method:'POST',body:JSON.stringify({parentUsername:parentUsername})});
  }

  // ── Parent ────────────────────────────────────────────────────
  async function getChildren(){
    var d=await apiFetch('/api/parent/children');
    return d.ok?d.children:[];
  }
  async function getChildDetail(studentUsername){
    return apiFetch('/api/parent/child-detail?u='+encodeURIComponent(studentUsername));
  }
  async function approveHomework(homeworkId,studentUsername){
    return apiFetch('/api/homework/approve',{method:'POST',body:JSON.stringify({homeworkId:homeworkId,studentUsername:studentUsername||''})});
  }
  async function rejectHomework(homeworkId,reason){
    return apiFetch('/api/homework/reject',{method:'POST',body:JSON.stringify({homeworkId:homeworkId,reason:reason||''})});
  }
  async function createTask(studentUsername,title,description,rewardText,starReward,dueDate){
    return apiFetch('/api/task/create',{method:'POST',body:JSON.stringify({studentUsername:studentUsername,title:title,description:description||'',rewardText:rewardText||'',starReward:starReward||1,dueDate:dueDate||''})});
  }
  async function approveTask(taskId){
    return apiFetch('/api/task/approve',{method:'POST',body:JSON.stringify({taskId:taskId})});
  }
  async function rejectTask(taskId,reason){
    return apiFetch('/api/task/reject',{method:'POST',body:JSON.stringify({taskId:taskId,reason:reason||''})});
  }
  async function approveLinkRequest(studentId,action){
    return apiFetch('/api/parent/approve-link',{method:'POST',body:JSON.stringify({studentId:studentId,action:action})});
  }
  async function removeChildFriend(studentId,friendId){
    return apiFetch('/api/parent/remove-child-friend',{method:'POST',body:JSON.stringify({studentId:studentId,friendId:friendId})});
  }

  // ── Feed ──────────────────────────────────────────────────────
  async function getFeed(){
    return apiFetch('/api/feed');
  }
  async function createPost(body,badgeEmoji,badgeName,postType){
    return apiFetch('/api/feed/post',{method:'POST',body:JSON.stringify({body:body,badgeEmoji:badgeEmoji||'',badgeName:badgeName||'',postType:postType||'text'})});
  }
  async function likePost(postId,liked){
    return apiFetch('/api/feed/like',{method:'POST',body:JSON.stringify({postId:postId,liked:liked})});
  }
  async function addComment(postId,body){
    return apiFetch('/api/feed/comment',{method:'POST',body:JSON.stringify({postId:postId,body:body})});
  }
  async function getComments(postId){
    var d=await apiFetch('/api/feed/comments?post='+postId);
    return d.ok?d.comments:[];
  }

  // ── Friends ───────────────────────────────────────────────────
  async function getFriends(){
    var d=await apiFetch('/api/friends');
    return d.ok?d.friends:[];
  }
  async function addFriend(username){
    return apiFetch('/api/friends/add',{method:'POST',body:JSON.stringify({friendUsername:username})});
  }
  async function removeFriend(username){
    return apiFetch('/api/friends/remove',{method:'POST',body:JSON.stringify({friendUsername:username})});
  }

  // ── Leaderboard ───────────────────────────────────────────────
  async function getLeaderboard(){
    return apiFetch('/api/leaderboard');
  }

  return{
    GOOGLE_CLIENT_ID:GOOGLE_CLIENT_ID,
    BASE:BASE,
    // auth
    googleVerify:googleVerify,googleAuth:googleAuth,
    completeProfile:completeProfile,pinLogin:pinLogin,resetPin:resetPin,
    checkUsername:checkUsername,linkAccounts:linkAccounts,fullLogout:fullLogout,
    // profile
    getProfile:getProfile,updateProfile:updateProfile,updateAvatar:updateAvatar,
    // notifications
    getNotifications:getNotifications,markRead:markRead,
    // student
    getDashboard:getDashboard,uploadHomework:uploadHomework,getHomeworks:getHomeworks,
    getMyTasks:getMyTasks,completeTask:completeTask,getStarProgress:getStarProgress,
    getParents:getParents,sendLinkRequest:sendLinkRequest,
    // parent
    getChildren:getChildren,getChildDetail:getChildDetail,
    approveHomework:approveHomework,rejectHomework:rejectHomework,
    createTask:createTask,approveTask:approveTask,rejectTask:rejectTask,
    approveLinkRequest:approveLinkRequest,removeChildFriend:removeChildFriend,
    // feed
    getFeed:getFeed,createPost:createPost,likePost:likePost,
    addComment:addComment,getComments:getComments,
    // friends
    getFriends:getFriends,addFriend:addFriend,removeFriend:removeFriend,
    // leaderboard
    getLeaderboard:getLeaderboard,
    // token
    getToken:getToken,setToken:setToken,clearToken:clearToken,
  };
})();
