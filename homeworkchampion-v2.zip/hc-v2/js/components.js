// components.js
(function(){
  'use strict';

  function showToast(msg,type,duration){
    type=type||'default';duration=duration||3000;
    var c=document.getElementById('toast-container');
    if(!c){c=document.createElement('div');c.id='toast-container';document.body.appendChild(c);}
    var icons={success:'✅',error:'❌',warning:'⚠️',default:'ℹ️'};
    var t=document.createElement('div');
    t.className='toast toast-'+type;
    t.innerHTML='<span>'+(icons[type]||icons.default)+'</span><span>'+msg+'</span>';
    c.appendChild(t);
    setTimeout(function(){t.classList.add('toast-hide');setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},350);},duration);
  }

  // STUDENT: Home | Tasks | Feed | Rank | Me
  // PARENT:  Home | Feed | Settings
  function createBottomNav(activeKey,role){
    role=role||'student';
    var px=rootPrefix();
    var items=role==='parent'?[
      {href:px+'parent/parent-dashboard.html',icon:'🏠',label:'Home',   key:'home'},
      {href:px+'social/feed.html',            icon:'👥',label:'Feed',   key:'social'},
      {href:px+'settings/settings.html',      icon:'⚙️',label:'Settings',key:'settings'},
    ]:[
      {href:px+'student/student-dashboard.html',icon:'🏠',label:'Home',  key:'home'},
      {href:px+'student/assignments.html',      icon:'📚',label:'Tasks', key:'assignments'},
      {href:px+'social/feed.html',              icon:'👥',label:'Feed',  key:'social'},
      {href:px+'student/leaderboard.html',      icon:'🏆',label:'Rank',  key:'leaderboard'},
      {href:px+'student/profile.html',          icon:'👤',label:'Me',    key:'profile'},
    ];
    var h='<nav class="bottom-nav">';
    items.forEach(function(i){
      h+='<a href="'+i.href+'" class="bottom-nav-item'+(activeKey===i.key?' active':'')+'">';
      h+='<span class="bnav-icon">'+i.icon+'</span><span>'+i.label+'</span></a>';
    });
    return h+'</nav>';
  }

  function avatarHTML(user,sizeClass){
    sizeClass=sizeClass||'';
    if(user&&user.avatar_url){return'<img src="'+user.avatar_url+'" class="avatar '+sizeClass+'" style="object-fit:cover">';}
    var n=(user&&user.name)||'U';
    var ini=n.split(' ').map(function(w){return w[0]||'';}).join('').toUpperCase().slice(0,2);
    return'<div class="avatar '+sizeClass+'" style="background:var(--primary-bg);color:var(--primary)">'+ini+'</div>';
  }

  function timeAgo(ts){
    var diff=Date.now()-(ts*1000||ts);
    if(diff<60000) return'Just now';
    if(diff<3600000) return Math.floor(diff/60000)+'m ago';
    if(diff<86400000) return Math.floor(diff/3600000)+'h ago';
    return Math.floor(diff/86400000)+'d ago';
  }

  function toggleSwitch(id,checked){
    return'<button class="toggle'+(checked?' on':'')+'" id="'+id+'" onclick="this.classList.toggle(\'on\')"></button>';
  }

  window.showToast=showToast;
  window.createBottomNav=createBottomNav;
  window.avatarHTML=avatarHTML;
  window.timeAgo=timeAgo;
  window.toggleSwitch=toggleSwitch;
  window.injectBottomNav=function(k,r){var el=document.getElementById('bottom-nav');if(el)el.outerHTML=createBottomNav(k,r);};
  window.SAMPLE_ASSIGNMENTS=[];
  window.SAMPLE_BADGES=[];
  window.assignmentCard=function(){return'';};
  window.avatarInitials=function(n){return'<div class="avatar">'+n.slice(0,2)+'</div>';};
})();
