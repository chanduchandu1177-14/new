// app.js — Core app logic
(function(){
  'use strict';

  function hydrateUserFields(){
    var user=getUser();if(!user) return;
    var fields=document.querySelectorAll('[data-user]');
    for(var i=0;i<fields.length;i++){var k=fields[i].getAttribute('data-user');if(user[k]!==undefined)fields[i].textContent=user[k];}
    var avEls=document.querySelectorAll('[data-user-avatar]');
    for(var j=0;j<avEls.length;j++){var n=user.name||'U';avEls[j].textContent=n.split(' ').map(function(w){return w[0];}).join('').toUpperCase().slice(0,2);}
  }
  function registerSW(){
    if(!('serviceWorker' in navigator)) return;
    navigator.serviceWorker.register(rootPrefix()+'service-worker.js').catch(function(){});
  }
  document.addEventListener('DOMContentLoaded',function(){hydrateUserFields();registerSW();});
  window.HC={hydrateUserFields:hydrateUserFields};
})();
