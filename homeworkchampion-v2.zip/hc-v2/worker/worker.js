// HomeworkChampion — Worker v10 (D1 + R2)
// Bindings: HC_DB (D1), HC_R2 (R2), JWT_SECRET, GOOGLE_CLIENT_ID

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
};
const ok  = (d,s=200) => new Response(JSON.stringify(d),{status:s,headers:{...CORS,'Content-Type':'application/json'}});
const err = (m,s=400) => ok({ok:false,error:m},s);

// ── JWT ───────────────────────────────────────────────────────
async function jwtSign(payload,secret){
  const h=btoa(JSON.stringify({alg:'HS256',typ:'JWT'})).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');
  const b=btoa(JSON.stringify(payload)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');
  const d=h+'.'+b;
  const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const s=await crypto.subtle.sign('HMAC',k,new TextEncoder().encode(d));
  return d+'.'+btoa(String.fromCharCode(...new Uint8Array(s))).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');
}
async function jwtVerify(token,secret){
  try{
    const p=token.split('.');if(p.length!==3) return null;
    const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['verify']);
    const sb=Uint8Array.from(atob(p[2].replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
    const v=await crypto.subtle.verify('HMAC',k,sb,new TextEncoder().encode(p[0]+'.'+p[1]));
    if(!v) return null;
    const pl=JSON.parse(atob(p[1].replace(/-/g,'+').replace(/_/g,'/')));
    if(pl.exp&&Date.now()/1000>pl.exp) return null;
    return pl;
  }catch(e){return null;}
}
async function getAuth(req,secret){
  const a=req.headers.get('Authorization')||'';
  if(!a.startsWith('Bearer ')) return null;
  return jwtVerify(a.slice(7).trim(),secret);
}
async function makeToken(profileId,role,secret){
  return jwtSign({sub:profileId,role,exp:Math.floor(Date.now()/1000)+604800},secret);
}

// ── Helpers ───────────────────────────────────────────────────
async function hashPin(pin){
  const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('hc2024-'+pin));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
function uuid(){
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g,c=>(c^crypto.getRandomValues(new Uint8Array(1))[0]&15>>c/4).toString(16));
}
async function verifyGoogle(idToken,clientId){
  try{
    const res=await fetch('https://oauth2.googleapis.com/tokeninfo?id_token='+idToken);
    const d=await res.json();
    if(d.error||d.aud!==clientId) return null;
    if(d.email_verified!=='true'&&d.email_verified!==true) return null;
    return{id:d.sub,email:d.email.toLowerCase(),name:d.name||d.email.split('@')[0],avatar:d.picture||''};
  }catch(e){return null;}
}
async function storeR2(bucket,key,base64,mime){
  const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));
  await bucket.put(key,bytes,{httpMetadata:{contentType:mime||'image/jpeg'}});
}
async function deleteR2(bucket,key){try{if(key)await bucket.delete(key);}catch(e){}}

// ── D1 helpers ────────────────────────────────────────────────
const q = (db,sql,...args) => db.prepare(sql).bind(...args).first();
const qs = (db,sql,...args) => db.prepare(sql).bind(...args).all().then(r=>r.results||[]);
const run = (db,sql,...args) => db.prepare(sql).bind(...args).run();

// ── Notifications ─────────────────────────────────────────────
async function notify(db,profileId,icon,title,body){
  await run(db,'INSERT INTO notifications(id,profile_id,icon,title,body) VALUES(?,?,?,?,?)',uuid(),profileId,icon,title,body);
}

// ── Auto-post on achievement ──────────────────────────────────
async function autoPost(db,authorId,body,badgeEmoji,badgeName,type){
  await run(db,'INSERT INTO posts(id,author_id,body,badge_emoji,badge_name,post_type,created_at) VALUES(?,?,?,?,?,?,unixepoch())',
    uuid(),authorId,body,badgeEmoji||'',badgeName||'',type||'achievement');
}

// ── Badge logic ───────────────────────────────────────────────
async function checkBadges(db,studentId){
  const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',studentId);
  const normalBadges=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=? AND type=?',studentId,'normal');
  const silverBadges=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=? AND type=?',studentId,'silver');
  const bronzeBadges=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=? AND type=?',studentId,'bronze');
  const goldBadges=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=? AND type=?',studentId,'gold');
  const diamondBadges=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=? AND type=?',studentId,'diamond');

  const ts=totalStars?.t||0;
  const nb=normalBadges?.c||0;
  const sb=silverBadges?.c||0;
  const bb=bronzeBadges?.c||0;
  const gb=goldBadges?.c||0;
  const db2=diamondBadges?.c||0;

  const badgesEarned=[];
  // 1 star = 1 toward normal badge; every 6 stars = 1 normal badge
  const normalEarned=Math.floor(ts/6);
  const normalNeeded=normalEarned-nb;
  for(let i=0;i<normalNeeded;i++){
    const id=uuid();
    await run(db,'INSERT INTO badges(id,student_id,type,emoji,name) VALUES(?,?,?,?,?)',id,studentId,'normal','🏅','Normal Badge');
    badgesEarned.push({id,type:'normal',emoji:'🏅',name:'Normal Badge'});
  }

  const curNormal=nb+normalNeeded;
  // 10 normal → silver
  const silverEarned=Math.floor(curNormal/10);
  for(let i=0;i<silverEarned-sb;i++){
    const id=uuid();
    await run(db,'INSERT INTO badges(id,student_id,type,emoji,name) VALUES(?,?,?,?,?)',id,studentId,'silver','🥈','Silver Badge');
    badgesEarned.push({id,type:'silver',emoji:'🥈',name:'Silver Badge'});
  }
  const curSilver=sb+(silverEarned-sb);
  // 20 normal → bronze
  const bronzeEarned=Math.floor(curNormal/20);
  for(let i=0;i<bronzeEarned-bb;i++){
    const id=uuid();
    await run(db,'INSERT INTO badges(id,student_id,type,emoji,name) VALUES(?,?,?,?,?)',id,studentId,'bronze','🥉','Bronze Badge');
    badgesEarned.push({id,type:'bronze',emoji:'🥉',name:'Bronze Badge'});
  }
  // 30 normal → gold
  const goldEarned=Math.floor(curNormal/30);
  for(let i=0;i<goldEarned-gb;i++){
    const id=uuid();
    await run(db,'INSERT INTO badges(id,student_id,type,emoji,name) VALUES(?,?,?,?,?)',id,studentId,'gold','🥇','Gold Badge');
    badgesEarned.push({id,type:'gold',emoji:'🥇',name:'Gold Badge'});
  }
  // 40 normal → diamond
  const diamondEarned=Math.floor(curNormal/40);
  for(let i=0;i<diamondEarned-db2;i++){
    const id=uuid();
    await run(db,'INSERT INTO badges(id,student_id,type,emoji,name) VALUES(?,?,?,?,?)',id,studentId,'diamond','💎','Diamond Badge');
    badgesEarned.push({id,type:'diamond',emoji:'💎',name:'Diamond Badge'});
  }

  // Auto-post for new badges
  for(const badge of badgesEarned){
    await autoPost(db,studentId,'🎉 I just earned the '+badge.name+'!',badge.emoji,badge.name,'badge');
    await notify(db,studentId,'🏅','Badge earned!','You earned: '+badge.name+' '+badge.emoji);
  }

  return{badgesEarned,totalStars:ts};
}

// ── Update streak ─────────────────────────────────────────────
async function updateStreak(db,studentId){
  const p=await q(db,'SELECT streak,last_sub_date FROM profiles WHERE id=?',studentId);
  const today=new Date().toISOString().split('T')[0];
  const yesterday=new Date(Date.now()-86400000).toISOString().split('T')[0];
  let streak=(p?.streak)||0;
  if(p?.last_sub_date===today){ /* already submitted today */ }
  else if(p?.last_sub_date===yesterday){ streak++; }
  else { streak=1; }
  await run(db,'UPDATE profiles SET streak=?,last_sub_date=? WHERE id=?',streak,today,studentId);
  return streak;
}

// ═════════════════════════════════════════════════════════════
export default {
  async fetch(req,env){
    if(req.method==='OPTIONS') return new Response(null,{status:204,headers:CORS});
    const url=new URL(req.url),path=url.pathname,method=req.method;
    const SECRET=env.JWT_SECRET||'hc-secret-2024';
    const GID=env.GOOGLE_CLIENT_ID||'';
    const db=env.HC_DB;
    const r2=env.HC_R2;
    const origin=url.origin;

    // ── Serve R2 photos ───────────────────────────────────────
    if(path.startsWith('/photo/')&&method==='GET'){
      if(!r2) return err('Storage not configured',500);
      const key=decodeURIComponent(path.replace('/photo/',''));
      const obj=await r2.get(key);
      if(!obj) return err('Not found',404);
      return new Response(obj.body,{headers:{...CORS,'Content-Type':obj.httpMetadata?.contentType||'image/jpeg','Cache-Control':'private,max-age=3600'}});
    }

    // ════════════════════════════════════════════════════════
    // ── POST /api/auth/google  ─────────────────────────────
    // ════════════════════════════════════════════════════════
    if(path==='/api/auth/google'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const gp=await verifyGoogle(b.idToken||'',GID);
      if(!gp) return err('Google token invalid',401);
      if(!db) return ok({ok:true,googleProfile:gp,profiles:[]});
      // Upsert user
      const existing=await q(db,'SELECT id FROM users WHERE id=?',gp.id);
      if(!existing){
        await run(db,'INSERT INTO users(id,email,name,google_av) VALUES(?,?,?,?)',gp.id,gp.email,gp.name,gp.avatar||'');
      } else {
        await run(db,'UPDATE users SET name=?,google_av=? WHERE id=?',gp.name,gp.avatar||'',gp.id);
      }
      // Get all profiles for this user
      const profiles=await qs(db,'SELECT id,username,role,name,avatar_url,grade,school FROM profiles WHERE user_id=?',gp.id);
      return ok({ok:true,googleProfile:gp,profiles,needsSetup:profiles.length===0});
    }

    // ── POST /api/auth/google-verify (alias for old flow) ──
    if(path==='/api/auth/google-verify'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const wantRole=(b.wantRole||'').toLowerCase().trim();
      const gp=await verifyGoogle(b.idToken||'',GID);
      if(!gp) return err('Google token invalid',401);
      if(!db) return ok({ok:true,needsSetup:true,wantRole,googleProfile:gp});
      const existing=await q(db,'SELECT id FROM users WHERE id=?',gp.id);
      if(!existing){
        await run(db,'INSERT INTO users(id,email,name,google_av) VALUES(?,?,?,?)',gp.id,gp.email,gp.name,gp.avatar||'');
      }
      const profiles=await qs(db,'SELECT id,username,role,name,avatar_url,grade FROM profiles WHERE user_id=?',gp.id);
      if(wantRole){
        const rp=profiles.find(p=>p.role===wantRole);
        if(rp){
          const token=await makeToken(rp.id,rp.role,SECRET);
          const full={...rp};
          return ok({ok:true,existingUser:true,alreadyHasRole:true,token,user:full});
        }
        return ok({ok:true,needsSetup:true,wantRole,googleProfile:gp});
      }
      if(!profiles.length) return ok({ok:true,needsSetup:true,wantRole:'',googleProfile:gp});
      if(profiles.length===1){
        const token=await makeToken(profiles[0].id,profiles[0].role,SECRET);
        return ok({ok:true,existingUser:true,singleProfile:true,token,user:profiles[0]});
      }
      return ok({ok:true,existingUser:true,singleProfile:false,profiles,googleProfile:gp});
    }

    // ── POST /api/auth/complete-profile ────────────────────
    if(path==='/api/auth/complete-profile'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{idToken,role,username,pin,grade,school,parentUsername}=b;
      if(!idToken||!username||!pin) return err('Missing fields');
      if(pin.length!==4||!/^\d+$/.test(pin)) return err('PIN must be 4 digits');
      if(username.length<3) return err('Username min 3 chars');
      if(!/^[a-zA-Z0-9_]+$/.test(username)) return err('Letters, numbers, underscores only');
      const gp=await verifyGoogle(idToken,GID);
      if(!gp) return err('Google token expired',401);
      if(!db) return err('DB not configured',500);
      // Check username taken
      const taken=await q(db,'SELECT id FROM profiles WHERE username=?',username.toLowerCase());
      if(taken) return err('Username @'+username+' already taken');
      // Check role already exists for this user
      const user=await q(db,'SELECT id FROM users WHERE id=?',gp.id);
      if(!user){
        await run(db,'INSERT INTO users(id,email,name,google_av) VALUES(?,?,?,?)',gp.id,gp.email,gp.name,gp.avatar||'');
      }
      const roleTaken=await q(db,'SELECT id FROM profiles WHERE user_id=? AND role=?',gp.id,role||'student');
      if(roleTaken) return err('You already have a '+role+' account',409);
      const finalRole=role||'student';
      const pinHash=await hashPin(pin);
      const profileId=uuid();
      await run(db,'INSERT INTO profiles(id,user_id,username,pin_hash,role,name,avatar_url,grade,school) VALUES(?,?,?,?,?,?,?,?,?)',
        profileId,gp.id,username.toLowerCase(),pinHash,finalRole,gp.name,gp.avatar||'',grade||'',school||'');
      // Link to parent if student provides parent username
      if(finalRole==='student'&&parentUsername&&parentUsername.trim()){
        const pProf=await q(db,'SELECT id FROM profiles WHERE username=? AND role=?',parentUsername.toLowerCase(),'parent');
        if(pProf){
          await run(db,'INSERT OR IGNORE INTO parent_child(id,parent_id,student_id,status) VALUES(?,?,?,?)',uuid(),pProf.id,profileId,'approved');
          await notify(db,pProf.id,'👶',gp.name+' linked to you!','Student @'+username+' is now linked to your account.');
        }
      }
      // Seed notifications
      await notify(db,profileId,'🎉','Welcome to HomeworkChampion!',finalRole==='student'?'Upload your homework diary to get started!':'Your children will link to you using your username.');
      const newUser=await q(db,'SELECT id,username,role,name,avatar_url,grade,school FROM profiles WHERE id=?',profileId);
      const token=await makeToken(profileId,finalRole,SECRET);
      return ok({ok:true,token,user:newUser},201);
    }

    // ── POST /api/auth/pin-login ───────────────────────────
    if(path==='/api/auth/pin-login'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{username,pin}=b;
      if(!username||!pin) return err('Username and PIN required');
      if(!db) return err('DB not configured',500);
      const profile=await q(db,'SELECT * FROM profiles WHERE username=?',username.toLowerCase());
      if(!profile) return err('@'+username+' not found',404);
      if(await hashPin(pin)!==profile.pin_hash) return err('Wrong PIN',401);
      await run(db,'UPDATE profiles SET last_sub_date=last_sub_date WHERE id=?',profile.id); // touch
      const{pin_hash,...safe}=profile;
      const token=await makeToken(profile.id,profile.role,SECRET);
      return ok({ok:true,token,user:safe});
    }

    // ── GET /api/auth/check-username ───────────────────────
    if(path==='/api/auth/check-username'&&method==='GET'){
      const u=(url.searchParams.get('u')||'').toLowerCase().trim();
      if(!u) return err('Username required');
      if(!db) return ok({ok:true,exists:false});
      const p=await q(db,'SELECT id,role FROM profiles WHERE username=?',u);
      return ok({ok:true,exists:!!p,role:p?.role||null});
    }

    // ── POST /api/auth/reset-pin ───────────────────────────
    if(path==='/api/auth/reset-pin'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{idToken,username,newPin}=b;
      if(!idToken||!username||!newPin) return err('Missing fields');
      if(newPin.length!==4||!/^\d+$/.test(newPin)) return err('PIN must be 4 digits');
      const gp=await verifyGoogle(idToken,GID);
      if(!gp) return err('Google token invalid',401);
      const profile=await q(db,'SELECT id,user_id FROM profiles WHERE username=?',username.toLowerCase());
      if(!profile) return err('Username not found',404);
      const user=await q(db,'SELECT id FROM users WHERE id=? AND id=?',gp.id,profile.user_id);
      if(!user) return err('Not authorized',403);
      await run(db,'UPDATE profiles SET pin_hash=? WHERE id=?',await hashPin(newPin),profile.id);
      return ok({ok:true,message:'PIN reset'});
    }

    // ── POST /api/auth/link-accounts (student links parent) ─
    if(path==='/api/auth/link-accounts'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{studentUsername,parentUsername}=b;
      if(!studentUsername||!parentUsername) return err('Both required');
      const sp=await q(db,'SELECT id,name FROM profiles WHERE username=? AND role=?',studentUsername.toLowerCase(),'student');
      const pp=await q(db,'SELECT id,name FROM profiles WHERE username=? AND role=?',parentUsername.toLowerCase(),'parent');
      if(!sp) return err('Student @'+studentUsername+' not found',404);
      if(!pp) return err('Parent @'+parentUsername+' not found',404);
      await run(db,'INSERT OR REPLACE INTO parent_child(id,parent_id,student_id,status) VALUES(?,?,?,?)',uuid(),pp.id,sp.id,'approved');
      await notify(db,pp.id,'👶',sp.name+' linked to you!','@'+studentUsername+' is now your linked child.');
      return ok({ok:true,message:'Linked!'});
    }

    // ════════════════════════════════════════════════════════
    // AUTH REQUIRED
    // ════════════════════════════════════════════════════════
    const auth=await getAuth(req,SECRET);
    if(!auth) return err('Unauthorized',401);
    const profileId=auth.sub;
    const authRole=auth.role;

    const me=await q(db,'SELECT * FROM profiles WHERE id=?',profileId);
    if(!me) return err('Profile not found',404);

    // ── GET /api/profile ───────────────────────────────────
    if(path==='/api/profile'&&method==='GET'){
      const{pin_hash,...safe}=me;
      const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',profileId);
      const badgeCount=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=?',profileId);
      const friendCount=await q(db,'SELECT COUNT(*) as c FROM friends WHERE profile_id=?',profileId);
      return ok({ok:true,user:{...safe,totalStars:totalStars?.t||0,badgeCount:badgeCount?.c||0,friendCount:friendCount?.c||0}});
    }

    // ── PUT /api/profile ───────────────────────────────────
    if(path==='/api/profile'&&method==='PUT'){
      let b={};try{b=await req.json();}catch(e){}
      const{name,grade,school,bio}=b;
      await run(db,'UPDATE profiles SET name=COALESCE(?,name),grade=COALESCE(?,grade),school=COALESCE(?,school),bio=COALESCE(?,bio) WHERE id=?',
        name||null,grade||null,school||null,bio||null,profileId);
      const{pin_hash,...safe}=await q(db,'SELECT * FROM profiles WHERE id=?',profileId);
      return ok({ok:true,user:safe});
    }

    // ── PUT /api/profile/avatar ────────────────────────────
    if(path==='/api/profile/avatar'&&method==='PUT'){
      let b={};try{b=await req.json();}catch(e){}
      const{photoBase64,mimeType}=b;
      if(!photoBase64) return err('Photo required');
      let avatarUrl='';
      if(r2){
        const ext=mimeType==='image/png'?'png':'jpg';
        const key='avatars/'+profileId+'.'+ext;
        await storeR2(r2,key,photoBase64,mimeType);
        avatarUrl=origin+'/photo/'+encodeURIComponent(key);
      } else {
        avatarUrl='data:'+(mimeType||'image/jpeg')+';base64,'+photoBase64;
      }
      await run(db,'UPDATE profiles SET avatar_url=? WHERE id=?',avatarUrl,profileId);
      return ok({ok:true,avatarUrl});
    }

    // ── GET /api/notifications ─────────────────────────────
    if(path==='/api/notifications'&&method==='GET'){
      const notifs=await qs(db,'SELECT * FROM notifications WHERE profile_id=? ORDER BY created_at DESC LIMIT 50',profileId);
      return ok({ok:true,notifications:notifs});
    }
    if(path==='/api/notifications/read'&&method==='PUT'){
      await run(db,'UPDATE notifications SET is_read=1 WHERE profile_id=?',profileId);
      return ok({ok:true});
    }

    // ════════════════════════════════════════════════════════
    // STUDENT
    // ════════════════════════════════════════════════════════

    // ── GET /api/student/dashboard ────────────────────────
    if(path==='/api/student/dashboard'&&method==='GET'){
      const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',profileId);
      const badges=await qs(db,'SELECT type,emoji,name FROM badges WHERE student_id=? ORDER BY earned_at DESC',profileId);
      const pendingHW=await qs(db,"SELECT id,title,status FROM homeworks WHERE student_id=? AND status IN ('pending','rejected') ORDER BY submitted_at DESC LIMIT 5",profileId);
      const pendingTasks=await qs(db,"SELECT id,title,star_reward,due_date FROM tasks WHERE student_id=? AND status='pending' ORDER BY due_date ASC LIMIT 5",profileId);
      const parents=await qs(db,'SELECT p.id,p.name,p.username,p.avatar_url FROM parent_child pc JOIN profiles p ON p.id=pc.parent_id WHERE pc.student_id=? AND pc.status=?',profileId,'approved');
      const pendingLinks=await qs(db,"SELECT p.name,p.username FROM parent_child pc JOIN profiles p ON p.id=pc.parent_id WHERE pc.student_id=? AND pc.status='pending'",profileId);
      const{pin_hash,...safe}=me;
      return ok({ok:true,user:{...safe,totalStars:totalStars?.t||0,badgeCount:badges.length},stats:{
        totalStars:totalStars?.t||0,
        streak:me.streak||0,
        points:me.points||0,
        badges:badges.slice(0,4),
        badgeCount:badges.length,
      },pendingHomeworks:pendingHW,pendingTasks,parents,pendingLinks});
    }

    // ── POST /api/homework/upload ─────────────────────────
    if(path==='/api/homework/upload'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{title,photoBase64,mimeType,diaryBase64,diaryMime,note}=b;
      if(!photoBase64&&!diaryBase64) return err('Photo required');
      const hwId=uuid();
      let imageKey='',imageUrl='',diaryKey='',diaryUrl='';
      if(photoBase64&&r2){
        const ext=mimeType==='image/png'?'png':'jpg';
        imageKey='hw/'+profileId+'/'+hwId+'.'+ext;
        await storeR2(r2,imageKey,photoBase64,mimeType);
        imageUrl=origin+'/photo/'+encodeURIComponent(imageKey);
      }
      if(diaryBase64&&r2){
        const ext=diaryMime==='image/png'?'png':'jpg';
        diaryKey='diary/'+profileId+'/'+hwId+'.'+ext;
        await storeR2(r2,diaryKey,diaryBase64,diaryMime);
        diaryUrl=origin+'/photo/'+encodeURIComponent(diaryKey);
      }
      await run(db,'INSERT INTO homeworks(id,student_id,title,image_key,image_url,diary_key,diary_url,note) VALUES(?,?,?,?,?,?,?,?)',
        hwId,profileId,title||'Homework',imageKey,imageUrl,diaryKey,diaryUrl,note||'');
      // Notify all linked parents
      const parents=await qs(db,"SELECT parent_id FROM parent_child WHERE student_id=? AND status='approved'",profileId);
      for(const p of parents){
        await notify(db,p.parent_id,'📸',me.name+' submitted homework!','Tap to review: '+(title||'Homework'));
      }
      // Update points
      await run(db,'UPDATE profiles SET points=points+10 WHERE id=?',profileId);
      return ok({ok:true,homeworkId:hwId,imageUrl,diaryUrl},201);
    }

    // ── GET /api/student/homeworks ────────────────────────
    if(path==='/api/student/homeworks'&&method==='GET'){
      const hws=await qs(db,'SELECT * FROM homeworks WHERE student_id=? ORDER BY submitted_at DESC',profileId);
      return ok({ok:true,homeworks:hws});
    }

    // ── GET /api/student/tasks ────────────────────────────
    if(path==='/api/student/tasks'&&method==='GET'){
      const tasks=await qs(db,'SELECT t.*,p.name as parent_name,p.username as parent_username FROM tasks t JOIN profiles p ON p.id=t.parent_id WHERE t.student_id=? ORDER BY t.created_at DESC',profileId);
      return ok({ok:true,tasks});
    }

    // ── POST /api/task/complete ───────────────────────────
    if(path==='/api/task/complete'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{taskId,proofBase64,proofMime}=b;
      if(!taskId) return err('Task ID required');
      const task=await q(db,'SELECT * FROM tasks WHERE id=? AND student_id=?',taskId,profileId);
      if(!task) return err('Task not found',404);
      if(task.status!=='pending') return err('Task not pending',409);
      let proofKey='',proofUrl='';
      if(proofBase64&&r2){
        const ext=proofMime==='image/png'?'png':'jpg';
        proofKey='tasks/'+profileId+'/'+taskId+'.'+ext;
        await storeR2(r2,proofKey,proofBase64,proofMime);
        proofUrl=origin+'/photo/'+encodeURIComponent(proofKey);
      }
      await run(db,'UPDATE tasks SET status=?,proof_key=?,proof_url=?,completed_at=unixepoch() WHERE id=?','completed',proofKey,proofUrl,taskId);
      await notify(db,task.parent_id,'✅',me.name+' completed: '+task.title,'Tap to approve and award '+task.star_reward+' star'+(task.star_reward>1?'s':'')+'!');
      return ok({ok:true});
    }

    // ── GET /api/student/star-progress ───────────────────
    if(path==='/api/student/star-progress'&&method==='GET'){
      const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',profileId);
      const badges=await qs(db,'SELECT type,emoji,name,earned_at FROM badges WHERE student_id=? ORDER BY earned_at DESC',profileId);
      const ts=totalStars?.t||0;
      const normalBadges=badges.filter(b=>b.type==='normal').length;
      const silverBadges=badges.filter(b=>b.type==='silver').length;
      const bronzeBadges=badges.filter(b=>b.type==='bronze').length;
      const goldBadges=badges.filter(b=>b.type==='gold').length;
      const diamondBadges=badges.filter(b=>b.type==='diamond').length;
      const nextNormal=6-((ts)%6);
      return ok({ok:true,totalStars:ts,streak:me.streak||0,normalBadges,silverBadges,bronzeBadges,goldBadges,diamondBadges,nextNormalIn:nextNormal===6?0:nextNormal,badges:badges.slice(0,4)});
    }

    // ── GET /api/student/parents ──────────────────────────
    if(path==='/api/student/parents'&&method==='GET'){
      const parents=await qs(db,'SELECT p.id,p.name,p.username,p.avatar_url,pc.status FROM parent_child pc JOIN profiles p ON p.id=pc.parent_id WHERE pc.student_id=?',profileId);
      return ok({ok:true,parents});
    }

    // ── POST /api/parent/link-request ─────────────────────
    if(path==='/api/parent/link-request'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{parentUsername}=b;
      if(!parentUsername) return err('Parent username required');
      const pProf=await q(db,'SELECT id,name FROM profiles WHERE username=? AND role=?',parentUsername.toLowerCase(),'parent');
      if(!pProf) return err('Parent @'+parentUsername+' not found',404);
      const existing=await q(db,'SELECT id,status FROM parent_child WHERE parent_id=? AND student_id=?',pProf.id,profileId);
      if(existing?.status==='approved') return err('Already linked');
      if(existing?.status==='pending') return err('Request already sent');
      await run(db,'INSERT OR REPLACE INTO parent_child(id,parent_id,student_id,status) VALUES(?,?,?,?)',uuid(),pProf.id,profileId,'pending');
      await notify(db,pProf.id,'🔗',me.name+' wants to link','Student @'+me.username+' sent you a link request. Tap to approve.');
      return ok({ok:true,message:'Link request sent!'});
    }

    // ════════════════════════════════════════════════════════
    // PARENT
    // ════════════════════════════════════════════════════════

    // ── GET /api/parent/children ──────────────────────────
    if(path==='/api/parent/children'&&method==='GET'){
      const links=await qs(db,'SELECT pc.student_id,pc.status,p.name,p.username,p.avatar_url,p.grade,p.school,p.streak,p.points FROM parent_child pc JOIN profiles p ON p.id=pc.student_id WHERE pc.parent_id=?',profileId);
      const children=await Promise.all(links.map(async l=>{
        const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',l.student_id);
        const pending=await q(db,"SELECT COUNT(*) as c FROM homeworks WHERE student_id=? AND status='pending'",l.student_id);
        const badgeCount=await q(db,'SELECT COUNT(*) as c FROM badges WHERE student_id=?',l.student_id);
        return{...l,totalStars:totalStars?.t||0,pendingReview:pending?.c||0,badgeCount:badgeCount?.c||0};
      }));
      return ok({ok:true,children});
    }

    // ── GET /api/parent/child-detail ──────────────────────
    if(path==='/api/parent/child-detail'&&method==='GET'){
      const studentUsername=url.searchParams.get('u')||'';
      const sp=await q(db,'SELECT id FROM profiles WHERE username=? AND role=?',studentUsername.toLowerCase(),'student');
      if(!sp) return err('Student not found',404);
      const link=await q(db,"SELECT status FROM parent_child WHERE parent_id=? AND student_id=? AND status='approved'",profileId,sp.id);
      if(!link) return err('Not your child',403);
      const child=await q(db,'SELECT * FROM profiles WHERE id=?',sp.id);
      const{pin_hash,...safe}=child;
      const totalStars=await q(db,'SELECT COALESCE(SUM(amount),0) as t FROM stars WHERE student_id=?',sp.id);
      const badges=await qs(db,'SELECT type,emoji,name,earned_at FROM badges WHERE student_id=? ORDER BY earned_at DESC LIMIT 10',sp.id);
      const homeworks=await qs(db,'SELECT * FROM homeworks WHERE student_id=? ORDER BY submitted_at DESC LIMIT 20',sp.id);
      const tasks=await qs(db,'SELECT * FROM tasks WHERE student_id=? AND parent_id=? ORDER BY created_at DESC',sp.id,profileId);
      const friends=await qs(db,'SELECT p.id,p.name,p.username,p.avatar_url FROM friends f JOIN profiles p ON p.id=f.friend_id WHERE f.profile_id=?',sp.id);
      return ok({ok:true,child:{...safe,totalStars:totalStars?.t||0,badgeCount:badges.length},badges,homeworks,tasks,friends});
    }

    // ── POST /api/homework/approve ─────────────────────────
    if(path==='/api/homework/approve'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{homeworkId,studentUsername}=b;
      if(!homeworkId) return err('Homework ID required');
      // Resolve student
      let studentId=null;
      if(studentUsername){
        const sp=await q(db,'SELECT id FROM profiles WHERE username=? AND role=?',studentUsername.toLowerCase(),'student');
        if(!sp) return err('Student not found',404);
        studentId=sp.id;
      }
      const hw=await q(db,'SELECT * FROM homeworks WHERE id=?',homeworkId);
      if(!hw) return err('Homework not found',404);
      studentId=studentId||hw.student_id;
      // Verify this parent is linked
      const link=await q(db,"SELECT id FROM parent_child WHERE parent_id=? AND student_id=? AND status='approved'",profileId,studentId);
      if(!link) return err('Not authorized',403);
      if(hw.status==='approved') return err('Already approved',409);
      // Approve
      await run(db,"UPDATE homeworks SET status='approved',image_key='',image_url='',diary_key='',diary_url='',reviewed_at=unixepoch() WHERE id=?",homeworkId);
      // Delete R2 photos
      if(r2){await deleteR2(r2,hw.image_key);await deleteR2(r2,hw.diary_key);}
      // Award star
      const starId=uuid();
      await run(db,'INSERT INTO stars(id,student_id,source,source_id,awarded_by,amount) VALUES(?,?,?,?,?,?)',starId,studentId,'homework',homeworkId,profileId,1);
      // Update points
      await run(db,'UPDATE profiles SET points=points+50 WHERE id=?',studentId);
      // Update streak
      const newStreak=await updateStreak(db,studentId);
      // Check badges
      const{badgesEarned,totalStars}=await checkBadges(db,studentId);
      // Notify student
      await notify(db,studentId,'⭐','Homework approved!','You earned 1 ⭐ star! Streak: '+newStreak+' days'+(badgesEarned.length?' · Badge earned: '+badgesEarned[0].name:''));
      // Auto-post if badge earned
      return ok({ok:true,badgesEarned,newStreak,totalStars});
    }

    // ── POST /api/homework/reject ─────────────────────────
    if(path==='/api/homework/reject'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{homeworkId,reason}=b;
      const hw=await q(db,'SELECT * FROM homeworks WHERE id=?',homeworkId);
      if(!hw) return err('Not found',404);
      const link=await q(db,"SELECT id FROM parent_child WHERE parent_id=? AND student_id=? AND status='approved'",profileId,hw.student_id);
      if(!link) return err('Not authorized',403);
      // Delete R2 photos to save storage
      if(r2){await deleteR2(r2,hw.image_key);await deleteR2(r2,hw.diary_key);}
      await run(db,"UPDATE homeworks SET status='rejected',image_key='',image_url='',diary_key='',diary_url='',reject_reason=?,reviewed_at=unixepoch() WHERE id=?",reason||'Please redo',homeworkId);
      await notify(db,hw.student_id,'🔄','Homework rejected','Reason: '+(reason||'Please redo and resubmit'));
      return ok({ok:true});
    }

    // ── POST /api/task/create ─────────────────────────────
    if(path==='/api/task/create'&&method==='POST'){
      if(authRole!=='parent') return err('Parent only',403);
      let b={};try{b=await req.json();}catch(e){}
      const{studentUsername,title,description,rewardText,starReward,dueDate}=b;
      if(!studentUsername||!title) return err('Student and title required');
      const sp=await q(db,'SELECT id,name FROM profiles WHERE username=? AND role=?',studentUsername.toLowerCase(),'student');
      if(!sp) return err('Student @'+studentUsername+' not found',404);
      const link=await q(db,"SELECT id FROM parent_child WHERE parent_id=? AND student_id=? AND status='approved'",profileId,sp.id);
      if(!link) return err('Not your child',403);
      const taskId=uuid();
      const stars=Math.min(10,Math.max(1,parseInt(starReward)||1));
      await run(db,'INSERT INTO tasks(id,parent_id,student_id,title,description,reward_text,star_reward,due_date) VALUES(?,?,?,?,?,?,?,?)',
        taskId,profileId,sp.id,title.trim(),description||'',rewardText||'',stars,dueDate||'');
      await notify(db,sp.id,'📋','New task from parent!',title+' — ⭐ '+stars+' star'+(stars>1?'s':'')+' reward!'+(dueDate?' Due: '+dueDate:''));
      return ok({ok:true,taskId},201);
    }

    // ── POST /api/task/approve ────────────────────────────
    if(path==='/api/task/approve'&&method==='POST'){
      if(authRole!=='parent') return err('Parent only',403);
      let b={};try{b=await req.json();}catch(e){}
      const{taskId}=b;
      const task=await q(db,'SELECT * FROM tasks WHERE id=? AND parent_id=?',taskId,profileId);
      if(!task) return err('Task not found',404);
      if(task.status==='approved') return err('Already approved',409);
      // Delete proof photo
      if(r2&&task.proof_key) await deleteR2(r2,task.proof_key);
      await run(db,"UPDATE tasks SET status='approved',proof_key='',proof_url='',approved_at=unixepoch() WHERE id=?",taskId);
      // Award stars
      const starId=uuid();
      await run(db,'INSERT INTO stars(id,student_id,source,source_id,awarded_by,amount) VALUES(?,?,?,?,?,?)',starId,task.student_id,'task',taskId,profileId,task.star_reward);
      await run(db,'UPDATE profiles SET points=points+? WHERE id=?',task.star_reward*25,task.student_id);
      const{badgesEarned,totalStars}=await checkBadges(db,task.student_id);
      await notify(db,task.student_id,'✅','Task approved!','You earned '+task.star_reward+' ⭐ star'+(task.star_reward>1?'s':'')+' for: '+task.title+(badgesEarned.length?' · Badge: '+badgesEarned[0].name:''));
      return ok({ok:true,badgesEarned,starsAwarded:task.star_reward,totalStars});
    }

    // ── POST /api/task/reject ─────────────────────────────
    if(path==='/api/task/reject'&&method==='POST'){
      if(authRole!=='parent') return err('Parent only',403);
      let b={};try{b=await req.json();}catch(e){}
      const{taskId,reason}=b;
      const task=await q(db,'SELECT * FROM tasks WHERE id=? AND parent_id=?',taskId,profileId);
      if(!task) return err('Task not found',404);
      if(r2&&task.proof_key) await deleteR2(r2,task.proof_key);
      await run(db,"UPDATE tasks SET status='rejected',proof_key='',proof_url='',reject_reason=? WHERE id=?",reason||'Please redo',taskId);
      await notify(db,task.student_id,'🔄','Task rejected','Reason: '+(reason||'Please redo')+'  · '+task.title);
      return ok({ok:true});
    }

    // ── POST /api/parent/approve-link ─────────────────────
    if(path==='/api/parent/approve-link'&&method==='POST'){
      if(authRole!=='parent') return err('Parent only',403);
      let b={};try{b=await req.json();}catch(e){}
      const{studentId,action}=b;
      await run(db,'UPDATE parent_child SET status=? WHERE parent_id=? AND student_id=?',action==='approve'?'approved':'rejected',profileId,studentId);
      if(action==='approve'){
        const sp=await q(db,'SELECT name,username FROM profiles WHERE id=?',studentId);
        await notify(db,studentId,'✅','Parent linked!',me.name+' (@'+me.username+') approved your link request.');
      }
      return ok({ok:true});
    }

    // ── POST /api/parent/remove-child-friend ──────────────
    if(path==='/api/parent/remove-child-friend'&&method==='POST'){
      if(authRole!=='parent') return err('Parent only',403);
      let b={};try{b=await req.json();}catch(e){}
      const{studentId,friendId}=b;
      const link=await q(db,"SELECT id FROM parent_child WHERE parent_id=? AND student_id=? AND status='approved'",profileId,studentId);
      if(!link) return err('Not your child',403);
      await run(db,'DELETE FROM friends WHERE profile_id=? AND friend_id=?',studentId,friendId);
      await run(db,'DELETE FROM friends WHERE profile_id=? AND friend_id=?',friendId,studentId);
      return ok({ok:true});
    }

    // ════════════════════════════════════════════════════════
    // FEED
    // ════════════════════════════════════════════════════════

    // ── GET /api/feed ─────────────────────────────────────
    if(path==='/api/feed'&&method==='GET'){
      // Get posts from self + friends
      const posts=await qs(db,`
        SELECT po.*,
          pr.name as author_name, pr.username as author_username, pr.avatar_url as author_avatar,
          (SELECT COUNT(*) FROM likes WHERE post_id=po.id) as like_count,
          (SELECT COUNT(*) FROM comments WHERE post_id=po.id) as comment_count,
          EXISTS(SELECT 1 FROM likes WHERE post_id=po.id AND profile_id=?) as user_liked
        FROM posts po
        JOIN profiles pr ON pr.id=po.author_id
        WHERE po.author_id=?
          OR po.author_id IN (SELECT friend_id FROM friends WHERE profile_id=?)
        ORDER BY po.created_at DESC LIMIT 30`,profileId,profileId,profileId);
      return ok({ok:true,posts});
    }

    // ── POST /api/feed/post ───────────────────────────────
    if(path==='/api/feed/post'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{body,badgeEmoji,badgeName,postType}=b;
      if(!body) return err('Body required');
      const postId=uuid();
      await run(db,'INSERT INTO posts(id,author_id,body,badge_emoji,badge_name,post_type) VALUES(?,?,?,?,?,?)',
        postId,profileId,body,badgeEmoji||'',badgeName||'',postType||'text');
      return ok({ok:true,postId},201);
    }

    // ── POST /api/feed/like ───────────────────────────────
    if(path==='/api/feed/like'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{postId,liked}=b;
      if(!postId) return err('Post ID required');
      if(liked){
        await run(db,'INSERT OR IGNORE INTO likes(post_id,profile_id) VALUES(?,?)',postId,profileId);
      } else {
        await run(db,'DELETE FROM likes WHERE post_id=? AND profile_id=?',postId,profileId);
      }
      const count=await q(db,'SELECT COUNT(*) as c FROM likes WHERE post_id=?',postId);
      return ok({ok:true,likes:count?.c||0});
    }

    // ── POST /api/feed/comment ────────────────────────────
    if(path==='/api/feed/comment'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{postId,body}=b;
      if(!postId||!body) return err('postId and body required');
      const cmtId=uuid();
      await run(db,'INSERT INTO comments(id,post_id,author_id,body) VALUES(?,?,?,?)',cmtId,postId,profileId,body.trim());
      const cmt=await q(db,'SELECT c.*,p.name as author_name,p.avatar_url as author_avatar FROM comments c JOIN profiles p ON p.id=c.author_id WHERE c.id=?',cmtId);
      return ok({ok:true,comment:cmt},201);
    }

    // ── GET /api/feed/comments ────────────────────────────
    if(path==='/api/feed/comments'&&method==='GET'){
      const postId=url.searchParams.get('post');
      if(!postId) return err('Post ID required');
      const comments=await qs(db,'SELECT c.*,p.name as author_name,p.avatar_url as author_avatar FROM comments c JOIN profiles p ON p.id=c.author_id WHERE c.post_id=? ORDER BY c.created_at ASC',postId);
      return ok({ok:true,comments});
    }

    // ════════════════════════════════════════════════════════
    // FRIENDS
    // ════════════════════════════════════════════════════════

    if(path==='/api/friends'&&method==='GET'){
      const friends=await qs(db,'SELECT p.id,p.name,p.username,p.avatar_url,p.role,p.grade FROM friends f JOIN profiles p ON p.id=f.friend_id WHERE f.profile_id=?',profileId);
      return ok({ok:true,friends});
    }
    if(path==='/api/friends/add'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{friendUsername}=b;
      if(!friendUsername) return err('Username required');
      const fp=await q(db,'SELECT id,name FROM profiles WHERE username=?',friendUsername.toLowerCase());
      if(!fp) return err('@'+friendUsername+' not found',404);
      if(fp.id===profileId) return err('Cannot add yourself');
      await run(db,'INSERT OR IGNORE INTO friends(profile_id,friend_id) VALUES(?,?)',profileId,fp.id);
      await run(db,'INSERT OR IGNORE INTO friends(profile_id,friend_id) VALUES(?,?)',fp.id,profileId);
      return ok({ok:true,message:'Friend added!'});
    }
    if(path==='/api/friends/remove'&&method==='POST'){
      let b={};try{b=await req.json();}catch(e){}
      const{friendUsername}=b;
      const fp=await q(db,'SELECT id FROM profiles WHERE username=?',friendUsername.toLowerCase());
      if(!fp) return err('Not found',404);
      await run(db,'DELETE FROM friends WHERE profile_id=? AND friend_id=?',profileId,fp.id);
      await run(db,'DELETE FROM friends WHERE profile_id=? AND friend_id=?',fp.id,profileId);
      return ok({ok:true});
    }

    // ── GET /api/leaderboard ──────────────────────────────
    if(path==='/api/leaderboard'&&method==='GET'){
      const top=await qs(db,'SELECT p.id,p.name,p.username,p.avatar_url,p.streak,p.points,COUNT(b.id) as badge_count,COALESCE(SUM(s.amount),0) as total_stars FROM profiles p LEFT JOIN badges b ON b.student_id=p.id LEFT JOIN stars s ON s.student_id=p.id WHERE p.role=? GROUP BY p.id ORDER BY p.points DESC LIMIT 20','student');
      return ok({ok:true,leaderboard:top});
    }

    return err('Not found',404);
  }
};
