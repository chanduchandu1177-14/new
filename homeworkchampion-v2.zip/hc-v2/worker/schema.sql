-- HomeworkChampion D1 Schema
-- Run: wrangler d1 execute HC_DB --file=worker/schema.sql

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ── Users (Google accounts) ───────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          TEXT PRIMARY KEY,          -- google sub id
  email       TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  google_av   TEXT DEFAULT '',           -- google avatar url
  created_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Profiles (one user can have student + parent profiles) ────
CREATE TABLE IF NOT EXISTS profiles (
  id          TEXT PRIMARY KEY,          -- uuid
  user_id     TEXT NOT NULL REFERENCES users(id),
  username    TEXT UNIQUE NOT NULL,
  pin_hash    TEXT NOT NULL,
  role        TEXT NOT NULL CHECK(role IN ('student','parent')),
  name        TEXT NOT NULL,
  avatar_url  TEXT DEFAULT '',
  grade       TEXT DEFAULT '',
  school      TEXT DEFAULT '',
  bio         TEXT DEFAULT '',
  points      INTEGER DEFAULT 0,
  streak      INTEGER DEFAULT 0,
  last_sub_date TEXT DEFAULT '',
  created_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Parent-Student links ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS parent_child (
  id          TEXT PRIMARY KEY,
  parent_id   TEXT NOT NULL REFERENCES profiles(id),
  student_id  TEXT NOT NULL REFERENCES profiles(id),
  status      TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  created_at  INTEGER NOT NULL DEFAULT (unixepoch()),
  UNIQUE(parent_id, student_id)
);

-- ── Homeworks ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS homeworks (
  id          TEXT PRIMARY KEY,
  student_id  TEXT NOT NULL REFERENCES profiles(id),
  title       TEXT NOT NULL DEFAULT 'Homework',
  image_key   TEXT DEFAULT '',          -- R2 object key (null after approved)
  image_url   TEXT DEFAULT '',          -- served URL
  diary_key   TEXT DEFAULT '',          -- diary/before photo R2 key
  diary_url   TEXT DEFAULT '',
  note        TEXT DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  reject_reason TEXT DEFAULT '',
  submitted_at  INTEGER NOT NULL DEFAULT (unixepoch()),
  reviewed_at   INTEGER DEFAULT NULL
);

-- ── Stars ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS stars (
  id           TEXT PRIMARY KEY,
  student_id   TEXT NOT NULL REFERENCES profiles(id),
  source       TEXT NOT NULL,           -- 'homework' | 'task'
  source_id    TEXT NOT NULL,
  awarded_by   TEXT NOT NULL REFERENCES profiles(id),
  amount       INTEGER NOT NULL DEFAULT 1,
  created_at   INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Badges ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS badges (
  id          TEXT PRIMARY KEY,
  student_id  TEXT NOT NULL REFERENCES profiles(id),
  type        TEXT NOT NULL,   -- 'normal'|'silver'|'bronze'|'gold'|'diamond'
  emoji       TEXT NOT NULL,
  name        TEXT NOT NULL,
  earned_at   INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Tasks (parent → student) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS tasks (
  id          TEXT PRIMARY KEY,
  parent_id   TEXT NOT NULL REFERENCES profiles(id),
  student_id  TEXT NOT NULL REFERENCES profiles(id),
  title       TEXT NOT NULL,
  description TEXT DEFAULT '',
  reward_text TEXT DEFAULT '',
  star_reward INTEGER NOT NULL DEFAULT 1,
  due_date    TEXT DEFAULT '',
  status      TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','completed','approved','rejected')),
  proof_key   TEXT DEFAULT '',
  proof_url   TEXT DEFAULT '',
  reject_reason TEXT DEFAULT '',
  created_at  INTEGER NOT NULL DEFAULT (unixepoch()),
  completed_at INTEGER DEFAULT NULL,
  approved_at  INTEGER DEFAULT NULL
);

-- ── Posts (feed) ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS posts (
  id          TEXT PRIMARY KEY,
  author_id   TEXT NOT NULL REFERENCES profiles(id),
  body        TEXT NOT NULL,
  badge_emoji TEXT DEFAULT '',
  badge_name  TEXT DEFAULT '',
  post_type   TEXT DEFAULT 'text',     -- 'text'|'badge'|'achievement'
  created_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Likes ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS likes (
  post_id    TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  profile_id TEXT NOT NULL REFERENCES profiles(id),
  created_at INTEGER NOT NULL DEFAULT (unixepoch()),
  PRIMARY KEY (post_id, profile_id)
);

-- ── Comments ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS comments (
  id          TEXT PRIMARY KEY,
  post_id     TEXT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id   TEXT NOT NULL REFERENCES profiles(id),
  body        TEXT NOT NULL,
  created_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Friends (for feed) ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS friends (
  profile_id  TEXT NOT NULL REFERENCES profiles(id),
  friend_id   TEXT NOT NULL REFERENCES profiles(id),
  created_at  INTEGER NOT NULL DEFAULT (unixepoch()),
  PRIMARY KEY (profile_id, friend_id)
);

-- ── Notifications ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  id          TEXT PRIMARY KEY,
  profile_id  TEXT NOT NULL REFERENCES profiles(id),
  icon        TEXT DEFAULT '🔔',
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  is_read     INTEGER DEFAULT 0,
  created_at  INTEGER NOT NULL DEFAULT (unixepoch())
);

-- ── Indexes ───────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_profiles_username  ON profiles(username);
CREATE INDEX IF NOT EXISTS idx_profiles_user_id   ON profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_homeworks_student  ON homeworks(student_id);
CREATE INDEX IF NOT EXISTS idx_tasks_student      ON tasks(student_id);
CREATE INDEX IF NOT EXISTS idx_tasks_parent       ON tasks(parent_id);
CREATE INDEX IF NOT EXISTS idx_posts_author       ON posts(author_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifs_profile     ON notifications(profile_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_parent_child       ON parent_child(parent_id, student_id);
CREATE INDEX IF NOT EXISTS idx_friends            ON friends(profile_id);
